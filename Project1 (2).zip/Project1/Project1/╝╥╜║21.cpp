#include <iostream>
#include <mutex>
#include <vector>
#include <thread>
#include <atomic>
#include <memory>

// Lock Free Queue ����

using namespace std;
using namespace chrono;
const auto NUM_TEST = 10000000;
const auto KEY_RANGE = 1000;

class NODE {
public:
	int value;
	NODE* next;
	NODE() {
		next = nullptr;
	}
	NODE(int input_value) {
		next = nullptr;
		value = input_value;
	}
	~NODE() {}
};

class CQUEUE {
public:
	NODE* volatile head;
	NODE* volatile tail;

	mutex enqLock;
	mutex deqLock;
	bool CAS(NODE** now_, NODE* old_, NODE* new_) {
		return atomic_compare_exchange_strong(reinterpret_cast<atomic_llong*>(now_), reinterpret_cast<long long*>(&old_), *reinterpret_cast<long long*>(&new_));
	}
	bool CAS(NODE* volatile* now_, NODE* old_, NODE* new_) {
		return atomic_compare_exchange_strong(reinterpret_cast<atomic_llong volatile*>(now_), reinterpret_cast<long long*>(&old_), *reinterpret_cast<long long*>(&new_));
	}
	CQUEUE() {
		head = new NODE();
		tail = head;
	}
	~CQUEUE() {}

	void Init()
	{
		NODE* ptr;
		while (head->next != nullptr) {
			ptr = head->next;
			head->next = head->next->next;
			delete ptr;
		}
		tail = head;
	}

	bool Enq(int key)
	{
		NODE* e = new NODE(key);
		while (true) {
			NODE* last = tail;
			NODE* next = last->next;
			if (last != tail) continue;
			if (next == nullptr) {
				if (CAS(&(last->next), nullptr, e)) {
					CAS(&tail, last, e);
					return true;
				}
			}
			else
				CAS(&tail, last, next);
		}
		return false;
	}
	int Deq()
	{
		while (true) {
			NODE* first = head;
			NODE* last = tail;
			NODE* next = first->next;
			if (first != head) continue;
			if (first == last) {
				if (next == nullptr) {
					cout << "EMPTY\n";
					exit(-1);
				}
				CAS(&tail, last, next);
				continue;
			}
			int value = next->value;
			if (false == CAS(&head, first, next)) continue;
			//delete first;
			return value;
		}
		return 0;
	}

	void Display()
	{
		int c = 20;
		NODE* p = head->next;
		while (p != tail) {
			cout << p->value << ", ";
			p = p->next;
			c--;
			if (c == 0) break;
		}
	}
};

CQUEUE cqueue;

void ThreadFunc(int num_thread)
{
	int key;
	for (int i = 0; i < NUM_TEST / num_thread; i++) {
		if ((rand() % 2) || i < 10000 / num_thread)
			cqueue.Enq(i);
		else key = cqueue.Deq();
	}
}

int main()
{
	for (int num_thread = 1; num_thread <= 16; num_thread *= 2)
	{
		cqueue.Init();
		vector<thread> threads;

		auto s = high_resolution_clock::now();
		for (int i = 0; i < num_thread; ++i) {
			threads.emplace_back(ThreadFunc, num_thread);
		}
		for (auto& th : threads) th.join();
		auto e = high_resolution_clock::now();
		cout << "threads[" << num_thread << "]  ";
		cout << duration_cast<milliseconds>(e - s).count() << "ms\t";

		cqueue.Display();
		cout << endl;

	}

	return 0;
}